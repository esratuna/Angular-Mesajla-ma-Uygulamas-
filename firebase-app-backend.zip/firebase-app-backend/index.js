const express = require('express');
const {initializeApp} = require("firebase-admin/app");
const cors = require("cors");
const adminSdk = require("firebase-admin");
const serviceAccount = require("./firebase-auth.json");
const { json } = require('express');
const bodyParser = require("body-parser");

initializeApp({
  credential: adminSdk.credential.cert(serviceAccount),
  databaseURL: "https://butunleme-14fb4-default-rtdb.firebaseio.com/",

});
const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

const checkClaim = async(req , res , next) => {
  let auth = req.headers.authorization;
  if(auth){
    await adminSdk.auth().verifyIdToken(auth).then((decodeToken) => {
      if (!decodeToken.admin){
        res.status(403).json({message: "Yetkisiz İşlem!"});
      }

      next();
    })
    .catch((err) => {
      res.status(500).json({message: "Beklenmedik hata oluştu!"});
    })

}else {
  next();
}

};

app.use(checkClaim);

app.post("/setAdmin",async(req, res) => {
  const uid = req.body.uid;
  await adminSdk
    .auth()
    .setCustomUserClaims(uid, {admin : true})
    .then((r) => {})
    .catch(
      res
        .status(500)
        .json({message: "Merhaba! Beklenmedik bir hata ile karşılaşıldı"})
        );
  res.status(200).json({message: "Kullanıcı admin yapıldı"});
});

app.post("/deleteUser",async(req,res) => {
  const uid = req.body.uid;

  await adminSdk
    .auth()
    .deleteUser(uid)
    .then(user => {
      res
        .status(200)
        .json({message: "Kullanıcı kaydı silindi"});
    })
    .catch((err) => {
      res.status(500).json({message: "Beklenmedik ir hata oluştu"});
    })
});

app.get('/', async (req, res) => {
    let result;
    await adminSdk
      .auth()
      .listUsers()
      .then((res) => (result = res.users))
      .catch((err) => {
        res
          .status(500)
          .json({message: "Merhaba beklenmedik bir hata ile karşılaşıldı"});
      });
    res
      .status(200)
      .json(result);
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});